import kubernetes
import time
import os
import logging
import shutil
from kubernetes import client, config
from kubernetes.client.rest import ApiException

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.info("Starting project manager container")

# Constants
NAMESPACE = os.environ.get('NAMESPACE', 'default')
CHECKPOINT_INTERVAL = int(os.environ.get('CHECKPOINT_INTERVAL', 30))
MAX_RETRY_ATTEMPTS = 3
RETRY_DELAY = 5
SHARED_VOLUME_PATH = '/app/shared'
CHECKPOINT_DIR = '/app/checkpoints'

def load_kube_config():
    try:
        config.load_incluster_config()
        logger.info("Loaded in-cluster configuration")
    except config.ConfigException:
        config.load_kube_config()
        logger.info("Loaded local kube config")

def get_pod_status(pod_name):
    v1 = client.CoreV1Api()
    try:
        pods = v1.list_namespaced_pod(namespace=NAMESPACE, field_selector=f"metadata.name={pod_name}")
        if pods.items:
            return pods.items[0].status.phase
        else:
            logger.info(f"Pod {pod_name} not found in namespace {NAMESPACE}")
            return None
    except ApiException as e:
        logger.error(f"Error getting pod status: {e}")
        return None

def checkpoint_container(container_name):
    try:
        logger.info(f"Checkpointing {container_name}")
        os.makedirs(CHECKPOINT_DIR, exist_ok=True)
        for file in ['checkpoint.txt', 'mul_result.txt', 'div_result.txt']:
            src = os.path.join(SHARED_VOLUME_PATH, file)
            dst = os.path.join(CHECKPOINT_DIR, f"{container_name}_{file}")
            if os.path.exists(src):
                shutil.copy(src, dst)
                logger.info(f"Copied {src} to {dst}")
            else:
                logger.warning(f"Source file {src} not found")
        logger.info(f"Checkpoint completed for {container_name}")
    except Exception as e:
        logger.error(f"Error during checkpointing {container_name}: {e}")

def create_new_pod(pod_name, container_image):
    v1 = client.CoreV1Api()
    pod_manifest = {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": pod_name
        },
        "spec": {
            "containers": [{
                "name": "mul-div-container",
                "image": container_image,
                "command": ["python", "/app/mul_div.py"],
                "volumeMounts": [{
                    "name": "shared-data",
                    "mountPath": "/app/shared"
                }]
            }],
            "volumes": [{
                "name": "shared-data",
                "emptyDir": {}
            }],
            "restartPolicy": "Always"
        }
    }
    try:
        pod = v1.create_namespaced_pod(body=pod_manifest, namespace=NAMESPACE)
        logger.info(f"Created new pod: {pod_name}")
        return pod
    except ApiException as e:
        logger.error(f"Error creating new pod: {e}")
        raise

def delete_pod(pod_name):
    v1 = client.CoreV1Api()
    try:
        v1.delete_namespaced_pod(name=pod_name, namespace=NAMESPACE)
        logger.info(f"Deleted pod: {pod_name}")
    except ApiException as e:
        logger.error(f"Error deleting pod {pod_name}: {e}")

def migrate_container(old_pod_name, new_pod_name):
    logger.info(f"Starting migration from {old_pod_name} to {new_pod_name}")
    checkpoint_container(old_pod_name)

    container_image = "rishmitha88/mul-div-container:latest"
    for attempt in range(MAX_RETRY_ATTEMPTS):
        try:
            new_pod = create_new_pod(new_pod_name, container_image)
            break
        except Exception as e:
            logger.warning(f"Attempt {attempt + 1} failed to create new pod: {e}")
            if attempt == MAX_RETRY_ATTEMPTS - 1:
                logger.error("Max retry attempts reached. Migration failed.")
                return None
            time.sleep(RETRY_DELAY)

    # Wait for the new pod to be running
    for _ in range(30):  # Wait up to 5 minutes
        new_pod_status = get_pod_status(new_pod_name)
        if new_pod_status == 'Running':
            logger.info(f"New pod {new_pod_name} is running")
            break
        time.sleep(10)
    else:
        logger.error(f"New pod {new_pod_name} did not start in time")
        return None

    transfer_state(new_pod_name)
    delete_pod(old_pod_name)

    logger.info(f"Migration from {old_pod_name} to {new_pod_name} completed successfully")
    return new_pod_name

def read_container_state(pod_name):
    try:
        checkpoint_file = os.path.join(SHARED_VOLUME_PATH, 'checkpoint.txt')
        if os.path.exists(checkpoint_file):
            with open(checkpoint_file, 'r') as f:
                return f.read().strip()
        else:
            logger.warning(f"Checkpoint file not found for {pod_name}")
            return "INIT"
    except Exception as e:
        logger.error(f"Error reading container state: {e}")
        return "INIT"

def transfer_state(pod_name):
    v1 = client.CoreV1Api()
    try:
        for file in ['checkpoint.txt', 'mul_result.txt', 'div_result.txt']:
            src = os.path.join(CHECKPOINT_DIR, f"mul-div-container_{file}")
            dst = f"/app/shared/{file}"
            if os.path.exists(src):
                with open(src, 'r') as f:
                    data = f.read()
                exec_command = [
                    "/bin/sh",
                    "-c",
                    f"echo '{data}' > {dst}"
                ]
                v1.connect_get_namespaced_pod_exec(
                    pod_name,
                    NAMESPACE,
                    command=exec_command,
                    stderr=True, stdin=True,
                    stdout=True, tty=False
                )
                logger.info(f"Transferred {src} to {dst} in pod {pod_name}")
            else:
                logger.warning(f"Source file {src} not found")
    except Exception as e:
        logger.error(f"Error transferring state to pod {pod_name}: {e}")

def monitor_containers():
    while True:
        try:
            v1 = client.CoreV1Api()
            pods = v1.list_namespaced_pod(namespace=NAMESPACE)
            project_pod = next((pod for pod in pods.items if pod.metadata.name.startswith('project')), None)
            mul_div_pod = next((pod for pod in pods.items if pod.metadata.name.startswith('mul-div-container')), None)

            if project_pod:
                project_pod_name = project_pod.metadata.name
                logger.info(f"Found project pod: {project_pod_name}")

                mul_div_container = next((container for container in project_pod.spec.containers if container.name == 'mul-div-container'), None)
                if mul_div_container:
                    logger.info("mul-div-container found in project pod")
                    state = read_container_state(project_pod_name)
                    if state == 'multiplication_done':
                        logger.info("Multiplication completed. Initiating migration.")
                        new_pod_name = f"mul-div-container-{int(time.time())}"
                        if migrate_container(project_pod_name, new_pod_name):
                            logger.info(f"Migration to {new_pod_name} successful")
                            # Remove mul-div-container from project pod
                            project_pod.spec.containers = [c for c in project_pod.spec.containers if c.name != 'mul-div-container']
                            v1.replace_namespaced_pod(name=project_pod_name, namespace=NAMESPACE, body=project_pod)
                            logger.info("Removed mul-div-container from project pod")
                        else:
                            logger.error("Migration failed")

            if mul_div_pod:
                pod_name = mul_div_pod.metadata.name
                pod_status = mul_div_pod.status.phase
                logger.info(f"Found mul-div pod: {pod_name}, status: {pod_status}")

                if pod_status == 'Running':
                    state = read_container_state(pod_name)
                    if state == 'division_done':
                        logger.info(f"Division completed in {pod_name}. Terminating pod.")
                        delete_pod(pod_name)

            if not mul_div_pod and not (project_pod and mul_div_container):
                logger.warning("No mul-div-container found, creating a new one")
                create_new_pod("mul-div-container", "rishmitha88/mul-div-container:latest")

        except Exception as e:
            logger.error(f"Error in monitor_containers: {e}")
        time.sleep(CHECKPOINT_INTERVAL)

def main():
    load_kube_config()
    monitor_containers()

if __name__ == "__main__":
    main()
