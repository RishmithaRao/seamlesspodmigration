import os
import time
import logging
import psutil
import signal
# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants
SHARED_VOLUME_PATH = '/app/shared'
CHECKPOINT_FILE = os.path.join(SHARED_VOLUME_PATH, 'checkpoint.txt')
MUL_RESULT_FILE = os.path.join(SHARED_VOLUME_PATH, 'mul_result.txt')
DIV_RESULT_FILE = os.path.join(SHARED_VOLUME_PATH, 'div_result.txt')

# Signal handler
def signal_handler(signum, frame):
    logger.info(f"Received signal {signum}. Exiting gracefully.")
    exit(0)

# Check if checkpoint file exists
def check_checkpoint():
    return os.path.exists(CHECKPOINT_FILE)

# Read the current checkpoint
def read_checkpoint():
    try:
        with open(CHECKPOINT_FILE, 'r') as f:
            return f.read().strip()
    except FileNotFoundError:
        logger.warning("Checkpoint file not found. Starting from the beginning.")
        return None
    except IOError as e:
        logger.error(f"Error reading checkpoint file: {e}")
        return None

# Write a new checkpoint state
def write_checkpoint(state):
    try:
        with open(CHECKPOINT_FILE, 'w') as f:
            f.write(state)
        logger.info(f"Checkpoint written: {state}")
    except IOError as e:
        logger.error(f"Error writing checkpoint file: {e}")

# Write the result of a calculation to a file
def write_result(file_path, result):
    try:
        with open(file_path, 'w') as f:
            f.write(str(result))
        logger.info(f"Result written to {file_path}")
    except IOError as e:
        logger.error(f"Error writing result to {file_path}: {e}")

# Perform multiplication
def perform_multiplication():
    logger.info("Starting multiplication")
    try:
        result = 4 * 6
        write_result(MUL_RESULT_FILE, result)
        logger.info("Multiplication completed")
        write_checkpoint('multiplication_done')
    except Exception as e:
        logger.error(f"Error during multiplication: {e}")
        write_checkpoint('multiplication_failed')

# Perform division
def perform_division():
    logger.info("Starting division")
    try:
        # Simulate high CPU usage
        start_time = time.time()
        while time.time() - start_time < 60:  # Run for 60 seconds
            psutil.cpu_percent(interval=1)
            if psutil.virtual_memory().percent > 90:  # If memory usage is over 90%
                raise MemoryError("Memory usage too high")

        # Read multiplication result
        with open(MUL_RESULT_FILE, 'r') as f:
            mul_result = int(f.read().strip())

        result = mul_result / 4
        write_result(DIV_RESULT_FILE, result)
        logger.info("Division completed")
        write_checkpoint('division_done')
    except MemoryError as e:
        logger.error(f"Memory error during division: {e}")
        write_checkpoint('division_failed_memory')
    except Exception as e:
        logger.error(f"Error during division: {e}")
        write_checkpoint('division_failed')

# Main function
def main():
    # Register signal handlers
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    checkpoint = read_checkpoint()

    if checkpoint is None or checkpoint == 'multiplication_failed':
        perform_multiplication()
        logger.info("Multiplication completed. Waiting for migration...")
        # Wait indefinitely after multiplication
        while True:
            time.sleep(60)
    elif checkpoint == 'multiplication_done':
        perform_division()
    elif checkpoint == 'division_done':
        logger.info("All operations completed")
    else:
        logger.warning(f"Unknown checkpoint state: {checkpoint}")

    logger.info("Main task completed. Keeping container alive.")
    while True:
        try:
            logger.info("Container is alive. Current state:")
            if os.path.exists(CHECKPOINT_FILE):
                with open(CHECKPOINT_FILE, 'r') as f:
                    logger.info(f"Checkpoint: {f.read().strip()}")
            if os.path.exists(MUL_RESULT_FILE):
                with open(MUL_RESULT_FILE, 'r') as f:
                    logger.info(f"Multiplication result: {f.read().strip()}")
            if os.path.exists(DIV_RESULT_FILE):
                with open(DIV_RESULT_FILE, 'r') as f:
                    logger.info(f"Division result: {f.read().strip()}")
        except Exception as e:
            logger.error(f"Error in keep-alive loop: {e}")
        time.sleep(3600)  # Sleep for an hour

if __name__ == "__main__":
    main()

